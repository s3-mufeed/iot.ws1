Microbit Car Racing
===================
You can use A and B to move left and right.
Your Objective is to avoid hitting other cars as you progress.
Your car is the on LED located on the bottom of the Microbit LED matrix.
You will be able to accumilate points as you avoid cars.
Your final score will be shown at the end of the game.
Game will end if you hit any cars.
===================
How to build
===================
